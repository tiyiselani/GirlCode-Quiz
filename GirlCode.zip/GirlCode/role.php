
<?php
    session_start();
  
    if(isset($_POST['submit']))
    {
       
        if(($_POST)){

            header('Location: quizs.php');
           }
        
            else{

                echo "you didn't select";
            }
        }
            
     
    
?>
<!DOCTYPE html>
<html lang="en">
<head>

    <title>GradsProm</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
     <link rel="stylesheet" href="css/font-awesome.min.css">
     <link rel="stylesheet" href="css/aos.css">
     <link rel="stylesheet" href="css/owl.carousel.min.css">
     <link rel="stylesheet" href="css/owl.theme.default.min.css">   
     <link rel="stylesheet" href="css/quizs.css" type="text/css"/>


</head>
<body>
    
<h1 style="font-size:56px; color:#fff; text-align:center;"> &nbsp;GradsProm</h1>
    <hr style="border-width:3px; border-color:#fff">

     <h3 style="font-size:26px; color:#fff; text-align:center;">Welcome 
                    <?php echo $_SESSION['username'] ?>

               </h3>

   <div id="main-wrapper">
    <h3> please note the person who got high score will automatically be hired </h3>
    <h4>Rules for the Quiz</h4>
        <p> 1.The test is taken at the workplace and at the same time. <br><br>
        2.The test 20 minutes long.  <br><br>
        3.NO CHEATING!!<br><br>
        4.There is  only 1 attempt   <br><br>
        5.Be on time.GOODLUCK!!   <br><br>
    </p>
    


    <form name = "role" action="role.php" method="POST"  >
        <select name = "role">
        <option value="frontend" >
            Front-End Developer</option>
        <option value="backend">
            Back-End Developer</option>
            <option value="c++">
                c++ FullStack Developer </option>
                <option valeu ="c#">
                    C# FullStack Developer</option>
                    <option value="Java">
                        Java FullStack Developer</option>
                    
    </select>
    <input type="submit" name="submit" value="submit">
    </form>
  


    
</body>
</html>