<?php include 'dbconfig/config.php'; ?>

<?php 
//get the total number of questions
$query = "SELECT * FROM `questions`";

//GET results
$result = mysqli_query($con, $query);

$total = $result->num_rows;

?>

<!DOCTYPE html5>
<html>
    <head>
        <meta charset="utf-8">
        <title>GradsProm</title>
          <link rel="stylesheet" href="css/quizs.css" type="text/css"/>
          <link rel="stylesheet" href="css/style.css">
    </head>
    <body>
         <h1 style="font-size:56px; color:#fff; text-align:center;"> &nbsp;GradsProm</h1>
    <hr style="border-width:3px; border-color:#fff">

   
    
        
        <main>
            <div id="main-wrapper">
                <h2>Test your skills</h2>
                <p>This is a multiple choice quiz to test you knowledge of the Job position</p>
            <ul>
                <li><strong>Number of Questions: </strong><?php echo $total; ?></li>
                <li><strong>Type: </strong>Multiple choice</li>
                <li><strong>Estimated Time: </strong><?php echo $total * .5; ?> Minutes</li>
            </ul>
            <a href="question.php?n=1" class="start">Start Quiz</a>
            </div>
        </main>

      

       <!-- SCRIPTS -->
     <script src="js/jquery.min.js"></script>
     <script src="js/bootstrap.min.js"></script>
     <script src="js/aos.js"></script>
     <script src="js/owl.carousel.min.js"></script>
     <script src="js/smoothscroll.js"></script>
     <script src="js/custom.js"></script>

    </body>
</html>

<php?
