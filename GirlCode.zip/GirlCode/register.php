<?php

    ini_set('display_errors', 1);
    ini_set ('display_startup_errors', 1);
    error_reporting(E_ALL);

	require 'dbconfig/config.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title>GradsProm</title>
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
     <link rel="stylesheet" href="css/font-awesome.min.css">
     <link rel="stylesheet" href="css/aos.css">
     <link rel="stylesheet" href="css/owl.carousel.min.css">
     <link rel="stylesheet" href="css/owl.theme.default.min.css">
     <link rel="stylesheet" href="css/quizs.css" type="text/css"/>

   
     
	<script type="text/javascript">

    function PreviewImage() {
        var oFReader = new FileReader();
        oFReader.readAsDataURL(document.getElementById("imglink").files[0]);

        oFReader.onload = function (oFREvent) {
            document.getElementById("uploadPreview").src = oFREvent.target.result;
        };
    };
</script>
</head>
<body bgcolor="#191919">

<h1 style="font-size:56px; color:#fff; text-align:center;"> &nbsp;GradsProm</h1>
	<hr style="border-width:3px; border-color:#fff">

	<h5 align="right" style="color:#f7b32d">
		<a href="index.php" style="text-decoration:none; color:#f7f7f7"> HOME </a> &nbsp; | &nbsp; 
		<a href="register.php" style="text-decoration:none; color:#f7f7f7"> REGISTRATION </a> &nbsp; | &nbsp; 
		<a href="index.php" style="text-decoration:none; color:#f7f7f7"> LOGIN </a> &nbsp;
	</h5>
	
	<form class="myform" action="register.php" method="post" enctype="multipart/form-data" >
		<div id="main-wrapper">
		<center>
			<h2 style="font-size:56px; color:#fff;">User Registration</h2>
			<!-- <img id="uploadPreview" src="imgs/avatar.png" class="avatar"/><br> -->
			<!--<input type="file" id="imglink" name="imglink" accept=".jpg,.jpeg,.png" onchange="PreviewImage();"/>-->
		</center>
		
			<label><b>Full Name:</b></label><br>
			<input name="fullname" type="text" class="inputvalues" placeholder="Type your Full Name" required/><br>
			<label><b>Username:</b></label><br>
			<input name="username" type="text" class="inputvalues" placeholder="Type your username" required/><br>
			<label><b>Email:</b></label><br>
			<input name="email" type="email" class="inputvalues" placeholder="Type your email" required/><br>
			<label><b>Password:</b></label><br>
			<input name="password" type="password" class="inputvalues" placeholder="Your password" required/><br>
			<label><b>Confirm Password:</b></label><br>
			<input name="cpassword" type="password" class="inputvalues" placeholder="Confirm password" required/><br>
			<input name="submit_btn" type="submit" id="signup_btn" value="Sign Up"/><a href="index.php"><input type="button" id="back_btn" value="Back To Login"/></a><br>
			
		</form>
		
		<?php
			if(isset($_POST['submit_btn']))
			{
				
				$fullname = $_POST['fullname'];

				$username = $_POST['username'];
				$email = $_POST['email'];
				$password = $_POST['password'];
				$cpassword = $_POST['cpassword'];
				
				
				if($password==$cpassword)
				{
					
					$query= "select * from userinformation WHERE username='$username'";
					$query_run = mysqli_query($con,$query);
					
					if(mysqli_num_rows($query_run)>0)
					{
						
						echo '<script type="text/javascript"> alert("User already exists.. try another username") </script>';
					}
					
					else
					{
						
						$query= "insert into userinformation values('','$username','$password','$fullname', '$email')";
						$query_run = mysqli_query($con,$query);
						
						if($query_run)
						{
							echo '<script type="text/javascript"> alert("User Registered.. Go to login page to login") </script>';
						}
						else
						{
							echo '<script type="text/javascript"> alert("Error!") </script>';
						}
					}	
				}
				else
				{
					echo '<script type="text/javascript"> alert("Password and confirm password does not match!")</script>';	
				}
			}
		?>
	</div>
	<br>
<footer align="right" style="font-size:40px; text-align: center; color:#fff">The Cartels</footer>


     <!-- SCRIPTS -->
     <script src="js/jquery.min.js"></script>
     <script src="js/bootstrap.min.js"></script>
     <script src="js/aos.js"></script>
     <script src="js/owl.carousel.min.js"></script>
     <script src="js/smoothscroll.js"></script>
     <script src="js/custom.js"></script>
</body>
</html>