<?php
	session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>GradsProm</title>
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
     <link rel="stylesheet" href="css/font-awesome.min.css">
     <link rel="stylesheet" href="css/aos.css">
     <link rel="stylesheet" href="css/owl.carousel.min.css">
     <link rel="stylesheet" href="css/owl.theme.default.min.css">

     <!-- MAIN CSS -->
     <link rel="stylesheet" href="css/templatemo-digital-trend.css">
</head>
<body bgcolor="#191919">

	<h1 style="font-size:56px; color:#f7f7f7; text-align:center;"> &nbsp;GradsProm</h1>
	<hr style="border-width:3px; border-color:#f7f7f7">

	<h5 align="right" style="color:#f7b32d">
		<a href="index.php" style="text-decoration:none; color:#f7f7f7"> HOME </a> &nbsp; | &nbsp; 
		<a href="register.php" style="text-decoration:none; color:#f7f7f7"> REGISTRATION </a> &nbsp; | &nbsp; 
		<a href="index.php" style="text-decoration:none; color:#f7f7f7"> LOGIN </a> &nbsp;
		<h3>Welcome to 
				<?php echo $_SESSION['username'] ?>
			</h3>
	</h5>
	<div id="main-wrapper">
		<center>
			<h2>Profile Page</h2>
			<h3>Welcome to 
				<?php echo $_SESSION['username'] ?>
			</h3>
			<?php echo '<img class="avatar" src="'.$_SESSION["imglink"].'">';?>
		</center>
	
		<form class="myform" action="homepage.php" method="post">
			<input name="logout" type="submit" id="logout_btn" value="Log Out"/><br>
			
		</form>
		
		<?php
			if(isset($_POST['logout']))
			{
				session_destroy();
				header('location:index.php');
			}
		?>
	</div>
	<footer align="right" style="font-size:50px; text-align: center; color:#fff">The Cartels</footer>
		
</body>
</html>