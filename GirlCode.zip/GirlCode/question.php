<?php
include 'dbconfig/config.php';
?>

<?php
session_start();;
?>

<?php
//set question number
$number = (int)$_GET['n'];

//get the total
$query = "SELECT * FROM `questions`";
    
//GET results
$results = mysqli_query($con, $query);
    
$total = $results->num_rows;

//get the question
$query = "SELECT * FROM `questions` WHERE question_number = $number";
                    
//get results
$result = mysqli_query($con, $query);

$question = $result->fetch_assoc();

//get choices
$query = "SELECT * FROM `choices` WHERE question_number = $number";
                   
//get choices
$choices = mysqli_query($con, $query);

?>

<!DOCTYPE html5>
<html>
    <head>
    <title>GradsProm</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
     <link rel="stylesheet" href="css/font-awesome.min.css">
     <link rel="stylesheet" href="css/aos.css">
     <link rel="stylesheet" href="css/owl.carousel.min.css">
     <link rel="stylesheet" href="css/owl.theme.default.min.css">   
     <link rel="stylesheet" href="css/quizs.css" type="text/css"/>
    </head>
    <body bgcolor="#191919">
        
 
    <h1 style="font-size:56px; color:#fff; text-align:center;"> &nbsp;GradsProm</h1>
    <hr style="border-width:3px; border-color:#fff">

        
        <main>
                <div id="main-wrapper">
                <div class="current">Question <?php echo $question['question_number'];?> of <?php echo $total;?></div>
                <p class="question">
                    <?php echo $question['text'] ?>
                </p>
                <form method="POST" action="process.php">
                    <ul class="choices">
                        <?php while($row = $choices->fetch_assoc()): ?>
                        <li>
                            <input name="choice" type="radio" value="<?php  echo $row['id'];?>">
                            <?php echo $row['text']; ?>
                        </li>
                        <?php endwhile; ?>
                    </ul>
                    <input type="submit" value="Submit" class="mybutton"></button>
                    <input type="hidden" name="number" value="<?php echo $number; ?>">
                </form>
            </div>
        </main>
        <footer>
            <div class="container">
                Copyright &copy; 2022, The Cartel
            </div>
        </footer>
    </body>
</html>