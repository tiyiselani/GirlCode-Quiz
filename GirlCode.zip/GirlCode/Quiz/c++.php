

<!DOCTYPE html>
<html>
<head>
	<title>c++ fullstack page</title>
	<link rel="stylesheet" href="css/registration.css"/>
</head>
<body>

<ul class="quiz">
	<h1>C++ full stack </h1>
  <li>
    <h4>Identify the correct extention of the user_defined hearer file in c++?</h4>
    <ul class="choices">
      <li><label><input type="radio" name="question0" value="A"><span>.cpp</span></label></li>
      <li><label><input type="radio" name="question0" value="B"><span>.hg</span></label></li>
      <li><label><input type="radio" name="question0" value="C"><span>.h</span></label></li>
      <li><label><input type="radio" name="question0" value="D"><span>.hf</span></label></li>
    </ul>
  </li>
  <li>
    <h4>Identify the incorrect constructor type?</h4>
    <ul class="choices">
      <li><label><input type="radio" name="question1" value="A"><span>Friend Constructor</span></label></li>
      <li><label><input type="radio" name="question1" value="B"><span>Default constructor</span></label></li>
      <li><label><input type="radio" name="question1" value="C"><span>parameterized constructor</span></label></li>
      <li><label><input type="radio" name="question1" value="D"><span>copy constructor</span></label></li>
    </ul>
  </li>
  <li>
    <h4>C++ uses which approach?</h4>
    <ul class="choices">
      <li><label><input type="radio" name="question2" value="A"><span>right-left</span></label></li>
      <li><label><input type="radio" name="question2" value="B"><span>top-down</span></label></li>
      <li><label><input type="radio" name="question2" value="C"><span>left-right</span></label></li>
      <li><label><input type="radio" name="question2" value="D"><span>bottom--up/span></label></li>
    </ul>
  </li>

  <li>
    <h4>which of the following data types is supported in c++ but not in c?</h4>
    <ul class="choices">
      <li><label><input type="radio" name="question2" value="A"><span>int</span></label></li>
      <li><label><input type="radio" name="question2" value="B"><span>bool</span></label></li>
      <li><label><input type="radio" name="question2" value="C"><span>double</span></label></li>
      <li><label><input type="radio" name="question2" value="D"><span>float</span></label></li>
    </ul>
  </li>

  <li>
    <h4>which of the folowing is "adress of operator"?</h4>
    <ul class="choices">
      <li><label><input type="radio" name="question2" value="A"><span>*</span></label></li>
      <li><label><input type="radio" name="question2" value="B"><span>&</span></label></li>
      <li><label><input type="radio" name="question2" value="C"><span>[]</span></label></li>
      <li><label><input type="radio" name="question2" value="D"><span>&&</span></label></li>
    </ul>
  </li>
  
</ul>

<button class="view-results" onclick="returnScore()">Next questionn</button>

</body>
</html>
