

<!DOCTYPE html>
<html>
<head>
	<title>front end page</title>
	<link rel="stylesheet" href="registration.css"/>
</head>
<body>

<ul class="quiz">
	<h1>Front-end </h1>
  <form name="frontend" action="" method="post">
  <li>
    <h4>Struct's data members are ______ by defaul?</h4>
    <ul class="choices">
     <li><input type="radio" name="question0" value="A"><span>protected</span></li>
      <li><input type="radio" name="question0" value="B"><span>public</span></li>
      <li><input type="radio" name="question0" value="C"><span>private</span></li>
      <li><input type="radio" name="question0" value="D"><span>default</span></li>
    </ul>
  </li>
  <li>
    <h4>which of the following statements are correct for c# language?</h4>
    <ul class="choices">
    <li> <input type="radio" name="question1" value="A"><span>Every derived class does not defibe its own version of the virtual method</span></li>
     <li> <input type="radio" name="question1" value="B"><span>by default, the access mode for all methods in c# is virtual</span></li>
     <li> <input type="radio" name="question1" value="C"><span>If a derived class, does not define its own version of the virtual method, then the one present is the base class gets ued</span></li>
     <li> <input type="radio" name="question1" value="D"><span>All of theabove</span></li>
    </ul>
  </li>
  <li>
    <h4>which of the following keywords is used to refer base class constructor to subclass constructor?</h4>
    <ul class="choices">
     <li> <input type="radio" name="question2" value="A"><span>this</span></li>
      <li><input type="radio" name="question2" value="B"><span>static</span></li>
      <li><input type="radio" name="question2" value="C"><span>base</span></li>
     <li> <input type="radio" name="question2" value="D"><span>extend</span></li>
    </ul>
  </li>

  <li>
    <h4>The space required for structure variables is allocated on the Stack</h4>
    <ul class="choices">
     <li> <input type="radio" name="question3" value="A"><span>true</span></li>
      <li><input type="radio" name="question3" value="B"><span>false</span></li>
      <li><input type="radio" name="question3" value="C"><span>maybe</span></li>
      <li><input type="radio" name="question3" value="D"><span>cant't say</span></li>
    </ul>
  </li>

  <li>
    <h4>Abstract class methods contains_____?</h4>
    <ul class="choices">
     <li> <input type="radio" name="question4" value="A"><span>abstract methods</span></li>
     <li> <input type="radio" name="question4" value="B"><span>non abstract methos</span></li>
      <li><input type="radio" name="question4" value="C"><span>both</span></li>
     <li> <input type="radio" name="question4" value="D"><span>none</span></li>
    </ul>
  </li>
  
</ul>

<input type="submit" name="submit-frontend" value="Submit">
</form>

</body>
</html>