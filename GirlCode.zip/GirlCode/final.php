<?php session_start();
?>

<!DOCTYPE html5>
<html>
   <title>GradsProm</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
     <link rel="stylesheet" href="css/font-awesome.min.css">
     <link rel="stylesheet" href="css/aos.css">
     <link rel="stylesheet" href="css/owl.carousel.min.css">
     <link rel="stylesheet" href="css/owl.theme.default.min.css">   
     <link rel="stylesheet" href="css/quizs.css" type="text/css"/>
    <body>
        
      <h1 style="font-size:56px; color:#fff; text-align:center;"> &nbsp;GradsProm</h1>
    <hr style="border-width:3px; border-color:#fff">
        
        <main>
            <div id="main-wrapper">
                <h2>You are done!</h2>
                <p>
                    Congrats you have completed the test
                </p>
                <p>Final Score: <?php echo $_SESSION['score'];?></p>
                <a href="question.php?n=1" class="start"> Take Again</a>
            </div>
        </main>
        <form class="myform" action="homepage.php" method="post">
            <input name="logout" type="submit" id="logout_btn" value="Log Out"/><br>
            
        </form>
        
        <?php
            if(isset($_POST['logout']))
            {
                session_destroy();
                header('location:index.php');
            }
        ?>
        <footer>
            <div class="container">
                Copyright &copy; 2022, the Cartel
            </div>
        </footer>
    </body>
</html>